# -*- coding: utf-8 -*-
import RPi.GPIO as GPIO   #import the GPIO module from RPI.GPIO.
import time               #import the time module.
dhtPin = 18                #set 'dhtPin' as digital 18.
 
GPIO.setmode(GPIO.BCM)    #set gpio as BCM mode.
time.sleep(1)             #delay 1 second.
data=[]                   #init array

def test():
    loopCnt = 0
    #Host signal start
    GPIO.setup(dhtPin, GPIO.OUT) #To send a start signal, set the pin to output
    GPIO.output(dhtPin, GPIO.LOW)#Pin output low level
    time.sleep(0.02)              #delay 0.02 second. >=18ms Host start signal
    GPIO.output(dhtPin, GPIO.HIGH) #Pin output high level
    time.sleep(0.00004)          #delay 40us.
    #End of host signal

    #Read-signal preparation
    GPIO.setup(dhtPin, GPIO.IN)  #set gpio 9 as input mode.
    loopCnt = 0
    while GPIO.input(dhtPin)==GPIO.LOW:  #The normal low level here is 83US
        loopCnt +=1
        time.sleep(0.000001)
        if loopCnt > 100:       #It's wrong if the time is greater than 83US
            print("time out 2!")  #Print out time Out 2! Indicates that the data is wrong here
            break    #Exit the loop
    loopCnt = 0
    while GPIO.input(dhtPin)==GPIO.HIGH: #The normal low level here is 87US
        loopCnt +=1
        time.sleep(0.000001)
        if loopCnt > 100:       #It's an error if the time is greater than 87US
            print("time out 3!")  #Print out time Out 3! Indicates that the data is wrong here
            break   #Exit the loop
    #Read signal ready to end
    #Start reading 40 bits of data
    j = 0
    while j < 40:     #store 40 piecs of data.
        loopCnt = 0
        #The low level of 54MS is read, and each bit of data starts at the low level of 54US
        while GPIO.input(dhtPin) == GPIO.LOW:   #Instead of checking the 54US low level, we just wait for the low level to pass
            loopCnt +=1
            if loopCnt > 50000:  #If the low level is too long, it is not correct and the terminal prints time out 4! And exit the loop
               print("time out 4!")
               break
     
        start_time = time.time()  #Record the moment when the high level reading begins
        loopCnt = 0
        while GPIO.input(dhtPin) == GPIO.HIGH:   #Wait for the high level to pass
            loopCnt +=1
            if loopCnt > 50000:
               print("time out 5!")
               break

        stop_time = time.time() #The moment when the high level ends
        t = stop_time - start_time #Figure out the time it takes to read to the high level
        #The high level range of logic 0 is 23~ 27US, and the high level of logic 1 is 70US. 
        #Then we set less than 40US as logic 0, otherwise it is 1
        if t < 0.00004:   #If the high level time read is less than 40US
            data.append(0) #Add a 0 at the end of the array data
        else:
            data.append(1) # Add a 1 to the end of the array data
        j += 1 # Add one to read the next data
    
    #The 40bits were split into 5 bytes, 8 bits for each byte, namely, 
    #8 bits for high humidity, 8 bits for low humidity, 
    #8 bits for high temperature, 8 bits for low temperature, and 8 bits for checking
    humidity_bit = data[0:8]
    humidity_point_bit = data[8:16]
    temperature_bit = data[16:24]
    temperature_point_bit = data[24:32]
    check_bit = data[32:40]
    
    #Defines the value used to store the calculated value
    humidity = 0
    humidity_point = 0
    temperature = 0
    temperature_point = 0
    check = 0
 
    #calculate each data and checksum.
    for i in range(8):  #This is converting every bit of base 2 to base 10 and adding them up
        humidity += humidity_bit[i] * 2 ** (7 - i)   
        humidity_point += humidity_point_bit[i] * 2 ** (7 - i)
        temperature += temperature_bit[i] * 2 ** (7 - i)
        temperature_point += temperature_point_bit[i] * 2 ** (7 - i)
        check += check_bit[i] * 2 ** (7 - i)
    #checksum
    checksum = humidity + humidity_point + temperature + temperature_point

    
    #If the check value == humidity value + temperature value, then the received data is correct
    if check == checksum: 
        print('data is right')
        print("T: "+str(temperature)+", H: "+str(humidity))  #The terminal prints the temperature and humidity values in character form
    else:
        print('data is error')
        print("T: "+str(temperature)+", H: "+str(humidity)+ ", check: "+str(check)+", checksum: "+str(checksum))

if __name__ == '__main__':   #Program entrance
    try:
        while True:
            test() #call function test()
            data = []   #Clears the array data to prepare for the next data reception
            time.sleep(3)  #The read cycle needs to be greater than 2 seconds
        
    except KeyboardInterrupt:
        GPIO.cleanup()

