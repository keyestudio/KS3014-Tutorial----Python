# -*- coding:utf-8 -*-
import RPi.GPIO as GPIO
from time import sleep
from threading import Timer  #Library files for introducing timers
 
d_num = 0
b_num = 0
#Pin of each section of nixie tube
a = 24
b = 18
c = 6
d = 19
e = 26
f = 23
g = 5
dp = 13
#Pin of each digit of nixie tube
d1 = 4
d2 = 17
d3 = 27
d4 = 22

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
#set as output
GPIO.setup(a,GPIO.OUT)  
GPIO.setup(b,GPIO.OUT)  
GPIO.setup(c,GPIO.OUT)  
GPIO.setup(d,GPIO.OUT)  
GPIO.setup(e,GPIO.OUT)  
GPIO.setup(f,GPIO.OUT)  
GPIO.setup(g,GPIO.OUT)  
GPIO.setup(dp,GPIO.OUT)  
#set as output
GPIO.setup(d1,GPIO.OUT)  
GPIO.setup(d2,GPIO.OUT)  
GPIO.setup(d3,GPIO.OUT)  
GPIO.setup(d4,GPIO.OUT)  

#Set to high level, turn off the nixie tube
GPIO.output(d1,GPIO.HIGH)
GPIO.output(d2,GPIO.HIGH)
GPIO.output(d3,GPIO.HIGH)
GPIO.output(d4,GPIO.HIGH)

def d_0():  #display 0
    GPIO.output(a,GPIO.HIGH)
    GPIO.output(b,GPIO.HIGH)
    GPIO.output(c,GPIO.HIGH)
    GPIO.output(d,GPIO.HIGH)
    GPIO.output(e,GPIO.HIGH)
    GPIO.output(f,GPIO.HIGH)
    GPIO.output(g,GPIO.LOW)
    GPIO.output(dp,GPIO.LOW)
def d_1(): #display 1
    GPIO.output(a,GPIO.LOW)
    GPIO.output(b,GPIO.HIGH)
    GPIO.output(c,GPIO.HIGH)
    GPIO.output(d,GPIO.LOW)
    GPIO.output(e,GPIO.LOW)
    GPIO.output(f,GPIO.LOW)
    GPIO.output(g,GPIO.LOW)
    GPIO.output(dp,GPIO.LOW)
def d_2(): #display 2
    GPIO.output(a,GPIO.HIGH)
    GPIO.output(b,GPIO.HIGH)
    GPIO.output(c,GPIO.LOW)
    GPIO.output(d,GPIO.HIGH)
    GPIO.output(e,GPIO.HIGH)
    GPIO.output(f,GPIO.LOW)
    GPIO.output(g,GPIO.HIGH)
    GPIO.output(dp,GPIO.LOW)
def d_3():
    GPIO.output(a,GPIO.HIGH)
    GPIO.output(b,GPIO.HIGH)
    GPIO.output(c,GPIO.HIGH)
    GPIO.output(d,GPIO.HIGH)
    GPIO.output(e,GPIO.LOW)
    GPIO.output(f,GPIO.LOW)
    GPIO.output(g,GPIO.HIGH)
    GPIO.output(dp,GPIO.LOW)
def d_4():
    GPIO.output(a,GPIO.LOW)
    GPIO.output(b,GPIO.HIGH)
    GPIO.output(c,GPIO.HIGH)
    GPIO.output(d,GPIO.LOW)
    GPIO.output(e,GPIO.LOW)
    GPIO.output(f,GPIO.HIGH)
    GPIO.output(g,GPIO.HIGH)
    GPIO.output(dp,GPIO.LOW)
def d_5():
    GPIO.output(a,GPIO.HIGH)
    GPIO.output(b,GPIO.LOW)
    GPIO.output(c,GPIO.HIGH)
    GPIO.output(d,GPIO.HIGH)
    GPIO.output(e,GPIO.LOW)
    GPIO.output(f,GPIO.HIGH)
    GPIO.output(g,GPIO.HIGH)
    GPIO.output(dp,GPIO.LOW)
def d_6():
    GPIO.output(a,GPIO.HIGH)
    GPIO.output(b,GPIO.LOW)
    GPIO.output(c,GPIO.HIGH)
    GPIO.output(d,GPIO.HIGH)
    GPIO.output(e,GPIO.HIGH)
    GPIO.output(f,GPIO.HIGH)
    GPIO.output(g,GPIO.HIGH)
    GPIO.output(dp,GPIO.LOW)
def d_7():
    GPIO.output(a,GPIO.HIGH)
    GPIO.output(b,GPIO.HIGH)
    GPIO.output(c,GPIO.HIGH)
    GPIO.output(d,GPIO.LOW)
    GPIO.output(e,GPIO.LOW)
    GPIO.output(f,GPIO.LOW)
    GPIO.output(g,GPIO.LOW)
    GPIO.output(dp,GPIO.LOW)
def d_8():
    GPIO.output(a,GPIO.HIGH)
    GPIO.output(b,GPIO.HIGH)
    GPIO.output(c,GPIO.HIGH)
    GPIO.output(d,GPIO.HIGH)
    GPIO.output(e,GPIO.HIGH)
    GPIO.output(f,GPIO.HIGH)
    GPIO.output(g,GPIO.HIGH)
    GPIO.output(dp,GPIO.LOW)
def d_9():
    GPIO.output(a,GPIO.HIGH)
    GPIO.output(b,GPIO.HIGH)
    GPIO.output(c,GPIO.HIGH)
    GPIO.output(d,GPIO.HIGH)
    GPIO.output(e,GPIO.LOW)
    GPIO.output(f,GPIO.HIGH)
    GPIO.output(g,GPIO.HIGH)
    GPIO.output(dp,GPIO.LOW)

def b_show(bit):   #Choose which digital tube to turn on
    #Choose to activate the single-digit digital tube, 
    #which is the right-most digit of the 4-digit digital tube
    if(bit == 0):
        GPIO.output(d1,GPIO.LOW)
        GPIO.output(d2,GPIO.HIGH)
        GPIO.output(d3,GPIO.HIGH)
        GPIO.output(d4,GPIO.HIGH)
    if(bit == 1):   #Select the start digit digital tube
        GPIO.output(d1,GPIO.HIGH)
        GPIO.output(d2,GPIO.LOW)
        GPIO.output(d3,GPIO.HIGH)
        GPIO.output(d4,GPIO.HIGH)
    if(bit == 2):   #Select the digital tube that activates the hundreds digit number
        GPIO.output(d1,GPIO.HIGH)
        GPIO.output(d2,GPIO.HIGH)
        GPIO.output(d3,GPIO.LOW)
        GPIO.output(d4,GPIO.HIGH)
    if(bit == 3):   #Select the digital tube to activate thousands of digits
        GPIO.output(d1,GPIO.HIGH)
        GPIO.output(d2,GPIO.HIGH)
        GPIO.output(d3,GPIO.HIGH)
        GPIO.output(d4,GPIO.LOW)

def recongnition(num):
    if(num == 0):  #num = 0
        d_0()      #Call d_0() to display 0 on the digital tube
    if(num == 1):
        d_1()
    if(num == 2):
        d_2()
    if(num == 3):
        d_3()
    if(num == 4):
        d_4()
    if(num == 5):
        d_5()
    if(num == 6):
        d_6()
    if(num == 7):
        d_7()
    if(num == 8):
        d_8()
    if(num == 9):
        d_9()
        
def display():
    global b_num
    if(b_num == 0):  #The ones place, the one on the far right of the 4-digit digital tube
        ge = d_num%10 # So % is the cooperations, so for example, 1356%10 = 6, so you get the units digit of 1356
        recongnition(ge) #This function, called recongnition(), is the number displayed around the digital tube, at d_num=1356, which is 6
        b_show(0)  #Call the function b_show(), which controls the nibbit, so that the units digit is the rightmost digit that can be lit
    if(b_num == 1):  #ten
        shi = d_num%100 #I'm going to subtract the hundreds place，1356 % 100 = 56
        shi = shi/10  # 56 / 10 = 5 ，You get ten digits
        recongnition(shi)
        b_show(1)  #Enable the ten digit digital tube to be lit
    if(b_num == 2): #A one hundred - bit
        bai = d_num%1000  #Let's leave out the thousands first, for example：1356 % 1000 = 356 ，So we get rid of the 1
        bai = bai/100     #Then,356 / 100 = 3，The integers are equal to 3, so you get the hundreds
        recongnition(bai)
        b_show(2)  #So that the hundreds digit digital tube can be lit
    if(b_num == 3): #A one thousand - bit
        qian = d_num/1000 # 1356 / 1000 = 1 ，We get thousands
        recongnition(qian)
        b_show(3)  #So that the digital tube in the thousands can be lit
    b_num = b_num + 1  #b_num add 1，In order to show you all the numbers
    if(b_num >3): #Since the digital tube is four bits, the limit cannot be greater than three
        b_num = 0 #Greater than 3 is equal to 0
    t = Timer(timer_interval,display) #
    t.start()

timer_interval = 0.005   #Start the timer interrupt every 0.005 seconds
t = Timer(timer_interval,display)  #Timer() is the Timer function, which means display is executed every 0.005s
t.start() #On timer

print("test...")
while True:
    for num in range(0,10000):  #display 0~10000
        d_num = num  #num = d_num
        print(d_num) #Terminal print out : d_num
        sleep(1)  #delay 1s

GPIO.cleanup() #release all GPIO
