import RPi.GPIO as GPIO
from time import sleep

#define 74Hc595 pin
data = 17  #Serial digital input pin
rck = 27
sck = 22

#These hexadecimal numbers show data from 0 to 9
#Hexadecimal to binary,0x3F, 0011 1111
num = [0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, \
       0x7D, 0x07, 0x7F, 0x6F]

GPIO.setmode(GPIO.BCM)   #use BCM numbers
#set the 74HC595 Pin OUTPUT mode
GPIO.setup(data,GPIO.OUT)  
GPIO.setup(rck,GPIO.OUT)  
GPIO.setup(sck,GPIO.OUT)
#Set rck and sck to high first
GPIO.output(rck,GPIO.HIGH)
GPIO.output(sck,GPIO.HIGH)

def bitshift(dat):
    if dat == 0:
        da = num[0]
    if dat == 1:
        da = num[1]
    if dat == 2:
        da = num[2]
    if dat == 3:
        da = num[3]
    if dat == 4:
        da = num[4]
    if dat == 5:
        da = num[5]
    if dat == 6:
        da = num[6]
    if dat == 7:
        da = num[7]
    if dat == 8:
        da = num[8]
    if dat == 9:
        da = num[9]
    for a in range(0,8):
        GPIO.output(sck,GPIO.LOW)  #set sckPin LOW 
        if (da & 0x01) == 0x01:    #Judge whether the last bit is 1
            GPIO.output(data,GPIO.HIGH)  #1
        else:
            GPIO.output(data,GPIO.LOW)   #0
            #set sckPin HIGH , Move data to shift register
        GPIO.output(sck,GPIO.HIGH)
        #Move data one bit to the right
        da =da  >> 1

def display(num):
    #Clock pin of storage register is set to low level
    GPIO.output(rck,GPIO.LOW)
    #function, receive data
    bitshift(num)
    #Clock pin of storage register is set to high level
    #At this time, the data will be output from the Q0 ~ Q7 port
    GPIO.output(rck,GPIO.HIGH)

print("test...")
while True:
    for a in range(0,10):  #display 0~9
        display(a)
        sleep(1)
        
GPIO.cleanup()
