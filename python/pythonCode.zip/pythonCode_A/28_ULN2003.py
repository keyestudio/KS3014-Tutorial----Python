import RPi.GPIO as GPIO
import time
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)       # Numbers GPIOs by physical location
 
IN1 = 22   
IN2 = 27
IN3 = 17
IN4 = 4
GPIO.setup(IN1, GPIO.OUT)      # Set pin's mode is output
GPIO.setup(IN2, GPIO.OUT)
GPIO.setup(IN3, GPIO.OUT)
GPIO.setup(IN4, GPIO.OUT)
 
#Output the high and low level of each pin to drive the stepping motor
def setStep(w1, w2, w3, w4):  
	GPIO.output(IN1, w1)
	GPIO.output(IN2, w2)
	GPIO.output(IN3, w3)
	GPIO.output(IN4, w4)
 
def stop():                     # stop
	setStep(0, 0, 0, 0)
 
def backward(delay, steps):       # Counterclockwise rotation
	for i in range(0, steps):
		setStep(1, 0, 0, 0)
		time.sleep(delay)
		setStep(0, 1, 0, 0)
		time.sleep(delay)
		setStep(0, 0, 1, 0)
		time.sleep(delay)
		setStep(0, 0, 0, 1)
		time.sleep(delay)
 
def forward(delay, steps):     #lockwise rotation
	for i in range(0, steps):
		setStep(0, 0, 0, 1)
		time.sleep(delay)
		setStep(0, 0, 1, 0)
		time.sleep(delay)
		setStep(0, 1, 0, 0)
		time.sleep(delay)
		setStep(1, 0, 0, 0)
		time.sleep(delay)
 
def loop():
	while True:
		print "backward..."
		backward(0.003, 512)  # One cycle, four beats, four steps, so 2048/4 = 512 cycles to make one rotation
		
		print "stop..."
		stop()                 # stop
		time.sleep(3)          # sleep 3s
		
		print "forward..."
		forward(0.003, 512)
		
		print "stop..."
		stop()
		time.sleep(3)
 
if __name__ == '__main__':         # Program start from here
	try:
		loop()
	except KeyboardInterrupt:  # When 'Ctrl+C' is pressed.
	    GPIO.cleanup()     # Release resource
