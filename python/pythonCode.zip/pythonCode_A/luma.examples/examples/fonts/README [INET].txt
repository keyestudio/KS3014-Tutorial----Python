+#######################################+
#					#
# C&C: Red Alert [Internet] (TrueType)	#
# Version 1.002				#
# Built 2008-02-06			#
#					#
# Created by N3tRunn3r			#
#					#
+#######################################+


+###############+
#		#
# INFORMATIONS	#
#		#
+###############+

Do you know the fonts of the Command & Conquer classics such as C&C: Red Alert?
My plans were to firstly re-create these fonts for a personal use, for my C&C website and later for the C&C community.

Today I want to provide you with these fonts!

My "C&C: Red Alert [Internet] (TrueType)" font is a minifont or also called as a pixelfont.
Pixelfonts are very small but in a way amazingly beautiful looking and fascinating fonts.

These kind of fonts are mostly best by using them in sizes between 8pt and 12pt.
It depends by their developer's thoughts and usage.

I personally commend using my C&C: Red Alert fonts in a size of 10pt!
This size is also the original one which is used within Command & Conquer and C&C: Red Alert.

This "C&C: Red Alert [Internet] (TrueType)" font is that one being used inside the C&C: Red Alert Internet lobby.
Some character additions and updates to my fonts were done as well.

Please notice that a lot of signs, symbols, and special characters are still missing, but will be added in future.


+#######################+
#			#
# HOW-TO INSTALL	#
#			#
+#######################+

1.) Extract "C&C Red Alert [INET].ttf" out of this ZIP file, preferred is onto your Desktop
2.) Right-click this ttf-file and select "Install"
3.) Windows is now going to install this font on your machine


+###############+
#		#
# DISCLAIMER	#
#		#
+###############+

MY C&C: RED ALERT FONTS ARE 100% FREEWARE AND SO ABSOLUTELY FREE-TO-USE FOR YOUR PERSONAL AND/OR COMMERCIAL USE!!
IF YOU RUN A FONT-RELATED WEBSITE AND WOULD LIKE TO OFFER MY FONTS THERE, GO RIGHT AHEAD!!
KEEP THIS README.TXT FILE WITH MY SPECIFIC FONTS INTACT TO PROVE THEIR ORIGINAL EXTRACTION!!

YOU ARE "NOT" ALLOWED TO SELL AND/OR DISTRIBUTE MY FONTS FOR PROFIT!!
YOU ARE "NOT" ALLOWED TO ALTER AND/OR MODIFY MY FONTS AND THEIR SOURCE CODES!!
YOU ARE "NOT" ALLOWED TO CLAIM THE FONT'S EXTRACTION!!

THESE FONTS WERE CREATED BY N3TRUNN3R


+#######################+
#			#
# ADDITIONAL INFO	#
#			#
+#######################+

If you like to know some latest news about my fonts and/or have any questions about them, so contact me at:

n3trunn3r@hotmail.de

My website is currently offline and under maintenance. It will go back online in future.


Command & Conquer and Command & Conquer: Red Alert are still popular RTS games, developed by Westwood.
Both games were released in year 1995 and 1996.

Are you interested into playing the C&C classics online? Visit:

www.CNC-COMM.com
www.CNCNET.org

and

www.CNC-ONLINE.net


Have fun, and that's an order! :)


BEST REGARDS,
N3