import RPi.GPIO as GPIO
from time import sleep

#LED pin
red = 18
yellow = 23
green = 24

GPIO.setmode(GPIO.BCM)  # use BCM numbers
GPIO.setup(red,GPIO.OUT)  #set the ledPin OUTPUT mode
GPIO.setup(yellow,GPIO.OUT)
GPIO.setup(green,GPIO.OUT)

GPIO.output(red,GPIO.LOW)
GPIO.output(yellow,GPIO.LOW)
GPIO.output(green,GPIO.LOW)

while True:
    GPIO.output(red,GPIO.HIGH)
    sleep(5)
    GPIO.output(red,GPIO.LOW)
    
    GPIO.output(yellow,GPIO.HIGH) #turn on yellow_led
    sleep(0.5)
    GPIO.output(yellow,GPIO.LOW) #turn off yellow_led
    sleep(0.5)
    GPIO.output(yellow,GPIO.HIGH)
    sleep(0.5)
    GPIO.output(yellow,GPIO.LOW) 
    sleep(0.5)
    GPIO.output(yellow,GPIO.HIGH) 
    sleep(0.5)
    GPIO.output(yellow,GPIO.LOW) 
    sleep(0.5)
    
    GPIO.output(green,GPIO.HIGH)  #turn on green_led
    sleep(5)     #delay 5s
    GPIO.output(green,GPIO.LOW)   #turn off green_led
    
    
GPIO.cleanup()   #release all GPIO
