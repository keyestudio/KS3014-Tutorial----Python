#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <wiringPi.h>
#include <softPwm.h>

//define L293D pin
#define INA1 0  //BCM GPIO 17
#define INA2 2  //BCM GPIO 27
#define ENA  3  //BCM GPIO 22

void forward()
{
	digitalWrite(INA1,HIGH);
	digitalWrite(INA2,LOW);
	softPwmWrite(ENA, 80); //pwm : 0~100
}
void reverse()
{
	digitalWrite(INA1,LOW);
	digitalWrite(INA2,HIGH);
	softPwmWrite(ENA, 80);  //pwm : 0~100
}
void stop()
{
	digitalWrite(INA1,LOW);
	digitalWrite(INA2,LOW);
	softPwmWrite(ENA, 0);
}

int main(void)
{
	wiringPiSetup();
	pinMode(INA1,OUTPUT);
	pinMode(INA2,OUTPUT);
	softPwmCreate(ENA, 0, 100);
	
	while(1)
	{
		forward();
		delay(3000);
		stop();
		delay(2000);
		reverse();
		delay(3000);
		stop();
		delay(2000);
	}
	
	return 0;
}
