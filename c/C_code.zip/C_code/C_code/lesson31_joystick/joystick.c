#include <wiringPi.h>
#include <pcf8591.h>
#include <stdio.h>

#define Address 0x48
#define BASE 64
#define A0 BASE+0
#define A1 BASE+1
#define A2 BASE+2
#define A3 BASE+3

#define btnPin 25 //GPIO 26

int main(void)
{
   unsigned char x_val;
   unsigned char y_val;
   unsigned char z_val;
   wiringPiSetup();
   pcf8591Setup(BASE,Address);
   pinMode(25,INPUT);
        
   while(1)
   {
      x_val=analogRead(A0);  //read x
      y_val=analogRead(A1);  //read y
      z_val=digitalRead(25); //read z, button
      printf(" x:%d  y:%d  z:%d\n", x_val,y_val,z_val);
      if(z_val==1)
      printf("The key is presed!\n");
      delay(100);
   }
}
