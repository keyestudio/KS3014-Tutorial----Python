#include <wiringPi.h>
#include <stdio.h>

#define ledPin 1  //define led pin, BCM GPIO 18

int main()
{
  wiringPiSetup();  //Initialize wiringPi
  
  pinMode(ledPin,OUTPUT);  //set the ledPin OUTPUT mode
  
  while(1)
  { 
        digitalWrite(ledPin,HIGH);  //turn on led
        printf("turn on the LED\n");
        delay(500);       //delay 500ms
        digitalWrite(ledPin,LOW);   //turn off led
        printf("turn off the LED\n");
        delay(500);	  
  }
}
