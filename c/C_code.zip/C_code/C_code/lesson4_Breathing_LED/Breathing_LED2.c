#include <stdio.h>
#include <wiringPi.h>
#include <softPwm.h>  //Software PWM library

#define LED 1 

int main(void)
{
       int i = 0;
       wiringPiSetup();  //Initialize wiringPi
       softPwmCreate(LED, 0, 100);  //Create pin LED as the PWM output(0~100)
       while (1)
       {
              for(i=0; i<100; i++)
              {
                     softPwmWrite(LED, i);  //pwm write
                     delay(20);
                     printf("PWM = %d\n",i);
              }
              for(i=99; i>0; i--)
              {
                     softPwmWrite(LED, i);
                     delay(20);
                     printf("PWM = %d\n",i);
              }
       }
       return 0;
}
