#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wiringPi.h>
#include <pcf8591.h>
#include <lcd.h>
#define Address 0x48
#define BASE 64
#define A0 BASE+0
#define A1 BASE+1
#define A2 BASE+2
#define A3 BASE+3
void change(int num,char *src) //This function changes 1234 to 4321 of the string
{
	char temp = '\0';
	int m = 0;
	int i = 0;

	while(num != 0)
	{
		m = num%10;
		temp = m+'0';
		src[i] = temp;
		i++;
		num = num/10;
	}
	src[i] = '\0';
}

int main(void)
{
	unsigned char value;
	unsigned char dat;
	wiringPiSetup();
	pcf8591Setup(BASE,Address);            
	int fd;
	int i;
	if (wiringPiSetup() == -1){
		exit(1);
	}

	fd = lcdInit(2,16,4, 24,23, 3,2,0,7,0,0,0,0); //see /usr/local/include/lcd.h
	printf("%d", fd);
	if (fd == -1){
		printf("lcdInit 1 failed\n") ;
		return 1;
	}
    lcdClear(fd);
	while(1){
		value=analogRead(A0); 
		dat=(500 *  value) /256;
		int i = 0;
		int len = 0;
		char temp;                                           //Define an intermediate variable
		char  *src = (char*)malloc(sizeof(char)*100);
		change(dat,src);
		len = strlen(src);
		for(i = 0;i < len/2;i++)                              //Output the string in reverse order
		{
			temp = src[i];
			src[i] = src[len-i-1];
			src[len-i-1] = temp;
		}
		printf("Temperature:%dC\n",dat);
		lcdPosition(fd, 0, 0); 
		lcdPuts(fd, "Temperature");
		lcdPosition(fd, 0, 1); 
		lcdPuts(fd, src);
		delay(1000);
		lcdClear(fd);
	}
	return 0;
}
