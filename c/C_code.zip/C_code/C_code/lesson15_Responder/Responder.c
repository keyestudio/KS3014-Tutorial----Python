#include <wiringPi.h>

//define the pin
#define redled  25    //BCM GPIO 26
#define yellowled 24  //BCM GPIO 19
#define blueled 23    //BCM GPIO 13
#define redpin 4      //BCM GPIO 23
#define yellowpin 5   //BCM GPIO 24
#define bluepin 6     //BCM GPIO 25
#define restpin 1     //BCM GPIO 18

int red;
int yellow;
int blue;

void clear_led()// all LED off
{
   digitalWrite(redled,LOW);
   digitalWrite(blueled,LOW);
   digitalWrite(yellowled,LOW);
}
void RED_YES()// execute the code until red light is on; end cycle when reset button is pressed
{
   while(digitalRead(restpin)==1)
   {
      digitalWrite(redled,HIGH);
      digitalWrite(blueled,LOW);
      digitalWrite(yellowled,LOW);
   }
   clear_led();
}
void YELLOW_YES()// execute the code until yellow light is on; end cycle when reset button is pressed
{
   while(digitalRead(restpin)==1)
   {
      digitalWrite(redled,LOW);
      digitalWrite(blueled,LOW);
      digitalWrite(yellowled,HIGH);
   }
   clear_led();
}
void BLUE_YES()// execute the code until green light is on; end cycle when reset button is pressed
{
   while(digitalRead(restpin)==1)
   {
      digitalWrite(redled,LOW);
      digitalWrite(blueled,HIGH);
      digitalWrite(yellowled,LOW);
   }
   clear_led();
}

int main()
{
   wiringPiSetup();
   pinMode(redled,OUTPUT);
   pinMode(yellowled,OUTPUT);
   pinMode(blueled,OUTPUT);
   pinMode(redpin,INPUT);
   pinMode(yellowpin,INPUT);
   pinMode(bluepin,INPUT);
  
   while(1)
   { 
      //digital read button
      red=digitalRead(redpin);
      yellow=digitalRead(yellowpin);
      blue=digitalRead(bluepin);
      if(red==LOW)  //red is pressed
      {
         RED_YES(); 
      }
         
      if(yellow==LOW) //yellow is pressed
      {
         YELLOW_YES();
      }
      
      if(blue==LOW)  //blue is pressed
      {
         BLUE_YES();
      }
   }	
}
